import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProgramListingComponent } from './program-listing/program-listing.component';
import { ProgramCreationComponent } from './program-creation/program-creation.component';


const routes: Routes = [
  {path: '', component: ProgramListingComponent},
  {path: 'programs', component: ProgramListingComponent},
  {path: 'programs/add', component: ProgramCreationComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
