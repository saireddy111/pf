import { Component, OnInit } from '@angular/core';

@Component({
  
  selector: 'app-program-listing',
  templateUrl: './program-listing.component.html',
  styleUrls: ['./program-listing.component.scss']
})
export class ProgramListingComponent implements OnInit {

  programList = [];
  constructor() {
      const list = localStorage.getItem('programList');
      if(list){
        this.programList = JSON.parse(list);
      }
   }

  ngOnInit(): void {
  
  }

  removeProgram = (index) => {
    this.programList.splice(index,1);
    localStorage.setItem("programList",JSON.stringify(this.programList));
  }
}
