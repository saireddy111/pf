import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-program-creation',
  templateUrl: './program-creation.component.html',
  styleUrls: ['./program-creation.component.scss']
})
export class ProgramCreationComponent implements OnInit {

  programName = '';
  departmentName = '';
  zoneName= '';
  departments = ["department1","department2"];
  zones = ["zone1","zone2"];

  constructor(private router : Router) { 
  
  }

  ngOnInit(): void {
  }

  onSave = () => {
      const newProgram = {
        name: this.programName,
        department: this.departmentName,
        zone: this.zoneName
      }
      const list = localStorage.getItem('programList');
      let programList = []
      if(list){
        programList = JSON.parse(list);
      }else {
        programList = []
      }
      programList.push(newProgram);
      localStorage.setItem("programList",JSON.stringify(programList));

      this.router.navigateByUrl('/programs');
  }

}
