import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProgramListingComponent } from './program-listing/program-listing.component';
import { ProgramCreationComponent } from './program-creation/program-creation.component';

@NgModule({
  declarations: [
    AppComponent,
    ProgramListingComponent,
    ProgramCreationComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
